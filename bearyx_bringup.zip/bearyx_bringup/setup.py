import os
from glob import glob
from setuptools import setup

package_name = 'bearyx_bringup'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name + '/launch'), glob('launch/*.launch.py')),
        (os.path.join('share', package_name+ '/config'), glob('config/*')),
        (os.path.join('share/' + package_name + '/urdf'), glob('urdf/*.urdf')),
        (os.path.join('share/' + package_name + '/meshes/stl'), glob('meshes/stl/*.STL')),
        (os.path.join('share/' + package_name + '/meshes/stl'), glob('meshes/stl/*.dae')),
        (os.path.join('share/' + package_name + '/rviz'), glob('rviz/*.rviz')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='tesr',
    maintainer_email='tesrshop@gmal.com',
    description='TESR Beary-x Bringup',
    license='TESR',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'bearyx_driver = bearyx_bringup.bearyx_driver:main',
            'bearyx_imu = bearyx_bringup.bearyx_imu:main',
	    'tf_broadcaster_imu = bearyx_bringup.tf_broadcaster_imu:main',
	    'clear_alarm = bearyx_bringup.clear_alarm:main',
        'robot_position_publisher = bearyx_bringup.robot_position_publisher:main',
        ],
    },
)
