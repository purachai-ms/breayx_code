#!/usr/bin/python3
import rclpy
from rclpy.node import Node

import time
import serial
from sensor_msgs.msg import Temperature, Imu, Joy
import tf_transformations
from tf2_ros import TransformBroadcaster

comport = serial.Serial("/dev/wheeltec_controller",115200,timeout=5)
comport.close()
comport.open()

def checksum(data_raw,data_count):
    checksum_data = 0
    for count in range(0,data_count):
        checksum_data = checksum_data^data_raw[count]
    return checksum_data

def IMU_Trans(MSB, LSB):
    data_signed_value = (MSB << 8) | LSB
    if data_signed_value == 0x8000:
        data_signed_value = 0
    elif (data_signed_value&0x8000) == 0x8000:
        data_signed_value = -((0xFFFF - data_signed_value)+1)
    return data_signed_value

# variable for IMU and Odom
IMU_Odom_FrameHeader = 0x7B
IMU_Odom_FrameTail = 0x7D
IMU_Odom_dataLenght = 23
Accel_ratio = 1671.84
Gyroscope_ratio = 0.00026644

IMU_MPU6050_data = {
    'accele_x':0.00,
    'accele_y':0.00,
    'accele_z':0.00,
    'gyro_x':0.00,
    'gyro_y':0.00,
    'gyro_z':0.00,
    'linear_acceleration_x':0.00,
    'linear_acceleration_y':0.00,
    'linear_acceleration_z':0.00,
    'angular_velocity_x':0.00,
    'angular_velocity_y':0.00,
    'angular_velocity_z':0.00
}

def main(args=None):
    rclpy.init(args=args)
    node = rclpy.create_node('BearyX_imu')

    # Publisher object
    imu_publisherObject = node.create_publisher(Imu, 'imu' , 10)

    # Topic data
    imu = Imu()
    imu.header.frame_id = "imu_link" #"base_imu_link"

    accel_x = 0
    accel_y = 0
    accel_z = 0

    gyro_x = 0
    gyro_y = 0
    gyro_z = 0

    imu_roll = 0
    imu_pitch = 0 
    imu_yaw = 0
    last_time_IMU = 0.0

    now_IMU = time.time()
    imu_dt = now_IMU - last_time_IMU # sec unit
    last_time_IMU = now_IMU
    print("Beary-X is ready for operation.")

    while rclpy.ok:
        try:
            #rclpy.spin_once(node, executor=None) # for run IMU monitoring must comment out
            start_byte = int.from_bytes(comport.read(),"big")
            if start_byte == IMU_Odom_FrameHeader:
                data_buffer_IMU_Odom = comport.read(IMU_Odom_dataLenght)
                if data_buffer_IMU_Odom[22] == IMU_Odom_FrameTail:
                    try:
                        IMU_MPU6050_data['accele_x'] = IMU_Trans(data_buffer_IMU_Odom[7], data_buffer_IMU_Odom[8])
                        IMU_MPU6050_data['accele_y'] = IMU_Trans(data_buffer_IMU_Odom[9], data_buffer_IMU_Odom[10])
                        IMU_MPU6050_data['accele_z'] = IMU_Trans(data_buffer_IMU_Odom[11], data_buffer_IMU_Odom[12])
                        
                        IMU_MPU6050_data['gyros_y'] = -IMU_Trans(data_buffer_IMU_Odom[13], data_buffer_IMU_Odom[14])
                        IMU_MPU6050_data['gyros_x'] = IMU_Trans(data_buffer_IMU_Odom[15], data_buffer_IMU_Odom[16])
                        IMU_MPU6050_data['gyros_z'] = IMU_Trans(data_buffer_IMU_Odom[17], data_buffer_IMU_Odom[18])
                        
                        IMU_MPU6050_data['linear_acceleration_x'] = float(IMU_MPU6050_data['accele_x'] / Accel_ratio)
                        IMU_MPU6050_data['linear_acceleration_y'] = float(IMU_MPU6050_data['accele_y'] / Accel_ratio)
                        IMU_MPU6050_data['linear_acceleration_z'] = float(IMU_MPU6050_data['accele_z'] / Accel_ratio)
                        
                        IMU_MPU6050_data['angular_velocity_x'] = float(IMU_MPU6050_data['gyros_x'] * Gyroscope_ratio)
                        IMU_MPU6050_data['angular_velocity_y'] = float(IMU_MPU6050_data['gyros_y'] * Gyroscope_ratio)
                        IMU_MPU6050_data['angular_velocity_z'] = float(IMU_MPU6050_data['gyros_z'] * Gyroscope_ratio)

                        accel_x = IMU_MPU6050_data['linear_acceleration_x'] # unit m/s^2
                        accel_y = IMU_MPU6050_data['linear_acceleration_y'] # unit m/s^2
                        accel_z = IMU_MPU6050_data['linear_acceleration_z'] # unit m/s^2

                        gyro_x = IMU_MPU6050_data['angular_velocity_x'] # unit rad/s
                        gyro_y = IMU_MPU6050_data['angular_velocity_y'] # unit rad/s
                        gyro_z = IMU_MPU6050_data['angular_velocity_z'] # unit rad/s

                        """
                        print("========================================")
                        print("accele_x: " + str(accel_x))
                        print("accele_y: " + str(accel_y))
                        print("accele_z: " + str(accel_z))
                        print("========================================")
                        print("gyros_x: " + str(gyro_x))
                        print("gyros_y: " + str(gyro_y))
                        print("gyros_z: " + str(gyro_z))
                        """
                    
                    except :
                        #clean up on exit
                        print("Error from reading serial IMU_Odom.")

                    try:
                        ###################### IMU Part #####################
                        now_IMU = time.time()
                        imu_dt = now_IMU - last_time_IMU # sec unit
                        
                        diff_imu_roll = gyro_x * imu_dt  # rad unit
                        imu_roll = imu_roll + diff_imu_roll # rad unit

                        diff_imu_pitch = gyro_y * imu_dt  # rad unit
                        imu_pitch = imu_pitch + diff_imu_pitch # rad unit

                        diff_imu_yaw = gyro_z * imu_dt  # rad unit
                        imu_yaw = imu_yaw + diff_imu_yaw # rad unit

                        last_time_IMU = now_IMU
                        
                        imu.linear_acceleration.x = accel_x 
                        imu.linear_acceleration.y = accel_y 
                        imu.linear_acceleration.z = accel_z 
                        imu.linear_acceleration_covariance = [ 1e6, 0.0, 0.0,
                                                                0.0, 1e6, 0.0,
                                                                0.0, 0.0, 1e-6 ]

                        imu.angular_velocity.x = gyro_x
                        imu.angular_velocity.y = gyro_y
                        imu.angular_velocity.z = gyro_z           
                        imu.angular_velocity_covariance = [ 1e6, 0.0, 0.0,
                                                            0.0, 1e6, 0.0,
                                                            0.0, 0.0, 1e-6 ]

                        imu_orientation = tf_transformations.quaternion_from_euler(imu_roll, imu_pitch, imu_yaw)
                        imu.orientation.x = imu_orientation[0]
                        imu.orientation.y = imu_orientation[1]
                        imu.orientation.z = imu_orientation[2]
                        imu.orientation.w = imu_orientation[3]
                        imu.orientation_covariance = [  1e6, 0.0, 0.0,
                                                        0.0, 1e6, 0.0,
                                                        0.0, 0.0, 1e-6 ]
                        
                        imu.header.stamp = node.get_clock().now().to_msg()
                        imu_publisherObject.publish(imu)

                    except:
                        #clean up on exit
                        print("Error publish odom and imu.")

        except KeyboardInterrupt:
            comport.close()
            print("KeyboardInterrupt")
            print("Close program.")
            
            
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

