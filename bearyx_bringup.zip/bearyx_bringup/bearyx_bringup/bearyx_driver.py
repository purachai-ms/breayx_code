#!/usr/bin/python3
from socket import timeout
import os
import rclpy
from rclpy.node import Node
import math
import json

import threading
import subprocess

import time
import serial
import struct
from nav_msgs.msg import Odometry
from sensor_msgs.msg import Range, Imu, Joy, BatteryState
from geometry_msgs.msg import Twist, TransformStamped, PoseWithCovarianceStamped
import tf_transformations
from tf2_ros import TransformBroadcaster

from std_msgs.msg import String, Int8, Bool,Float32
from nav_msgs.msg import Odometry
from actionlib_msgs.msg import GoalID


# for tracking goal status
from action_msgs.msg import GoalStatusArray

# for maker
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray

import socket
import netifaces as ni


username = os.getenv("USER") or os.getenv("LOGNAME")
mac_address = ""
try:
    mac_address = ni.ifaddresses("wlo1")[17][0]["addr"]
except:
    mac_address = ni.ifaddresses("enp89s0")[17][0]["addr"]

ros_distro = os.getenv('ROS_DISTRO')

wifi_name = ""
try:
    wifi_name = os.popen('iwgetid -r').read().strip()
except:
    wifi_name = "Not connected"

bearyx_ip_address = ""
try:
    addresses = ni.ifaddresses("wlo1")
    bearyx_ip_address = addresses[ni.AF_INET][0]['addr']
except:
    bearyx_ip_address = "No ip"

ROS_Domain_Id = ""
try:
    ROS_Domain_Id = os.getenv('ROS_DOMAIN_ID', 'Default (0)')
except:
    ROS_Domain_Id = 0


BearyX_info = {
    "MAC":mac_address,
    "type":"Beary-X",
    "Lidar":"lsm10p front&back",
    "Controller fw ver.":"1.0",
    "ROS ver.":ros_distro,
    "gen":"2025",
    "WiFi":wifi_name,
    "ip":bearyx_ip_address,
    "ID":ROS_Domain_Id,
    "User name":username,
}



key = 0
flag = 0
buff = {}
angular_velocity = [0, 0, 0]
acceleration = [0, 0, 0]
magnetometer = [0, 0, 0]
angle_degree = [0, 0, 0]
wheels_vel = 0
last_valid_imu = [0, 0, 0]
offset_imu = [0, 0, 0]

Battery_Current = 0.00

comport = serial.Serial("/dev/main_controller",115200,timeout=5) # comport for connecting with driver controller
comport.close()
comport.open()

comport_imu = serial.Serial("/dev/imu",9600,timeout=5)
comport_imu.close()
comport_imu.open()

#comport_sensor = serial.Serial("/dev/bearyx_sensor",115200,timeout=1) # comport for connecting with sensor controller
#comport_sensor.close()
#comport_sensor.open()


# Checksum verification
def checkSumIMU(list_data, check_data):
    return sum(list_data) & 0xff == check_data

# Convert hex to IEEE floating-point number
def hex_to_short(raw_data):
    return list(struct.unpack("hhhh", bytearray(raw_data)))

# Handle serial port data
def handleSerialDataIMU(raw_data):
    global buff, key, angle_degree, magnetometer, acceleration, angular_velocity, pub_flag
    buff[key] = raw_data
    key += 1
    if buff[0] != 0x55:
        key = 0
        return
    if key < 11:  # Determine the length of the data based on the data length byte and get the corresponding length data
        return
    else:
        data_buff = list(buff.values())  # Get all values from the dictionary
        if buff[1] == 0x51:
            if checkSumIMU(data_buff[0:10], data_buff[10]):
                acceleration = [hex_to_short(data_buff[2:10])[i] / 32768.0 * 16 * 9.8 for i in range(0, 3)]
            else:
                print('0x51 checksum failed')

        elif buff[1] == 0x52:
            if checkSumIMU(data_buff[0:10], data_buff[10]):
                angular_velocity = [hex_to_short(data_buff[2:10])[i] / 32768.0 * 2000 * math.pi / 180 for i in range(0, 3)]

            else:
                print('0x52 checksum failed')

        elif buff[1] == 0x53:
            if checkSumIMU(data_buff[0:10], data_buff[10]):
                angle_degree = [hex_to_short(data_buff[2:10])[i] / 32768.0 * 180 for i in range(0, 3)]
                read_imu(angle_degree, wheels_vel)
            else:
                print('0x53 checksum failed')
        elif buff[1] == 0x54:
            if checkSumIMU(data_buff[0:10], data_buff[10]):
                magnetometer = hex_to_short(data_buff[2:10])
            else:
                print('0x54 checksum failed')

        else:
            print("No handler provided for data type " + str(buff[1]))
            print("Or data is incorrect")
            buff = {}
            key = 0

        buff = {}
        key = 0
        
def apply_offset(orentation, offset):
    adjusted_orentation = orentation + offset
    if adjusted_orentation > 180:
        adjusted_orentation -= 360
    elif adjusted_orentation < -180:
        adjusted_orentation += 360
    return adjusted_orentation

def read_imu(current_imu, wheels_vel):
    global last_valid_imu, offset_imu
    if wheels_vel > 0:
        last_valid_imu[0] = apply_offset(current_imu[0] + offset_imu[0], 0)
        last_valid_imu[1] = apply_offset(current_imu[1] + offset_imu[1], 0)
        last_valid_imu[2] = apply_offset(current_imu[2] + offset_imu[2], 0)
    else:
        offset_imu[0] = last_valid_imu[0] - current_imu[0]
        offset_imu[1] = last_valid_imu[1] - current_imu[1]
        offset_imu[2] = last_valid_imu[2] - current_imu[2]
        
def IMUThread(data):
    while True:
        try:
            buff_count = comport_imu.inWaiting()
        except Exception as e:
            print("exception: " + str(e))
            print("IMU lost connection, bad contact, or disconnected")
            exit(0)
        else:
            if buff_count > 0:
                buff_data = comport_imu.read(buff_count)
                for i in range(0, buff_count):
                    handleSerialDataIMU(buff_data[i])

def checksum(data_raw,data_count):
    checksum_data = 0
    for count in range(0,data_count):
        checksum_data = checksum_data^data_raw[count]
    return checksum_data

def IMU_Trans(MSB, LSB):
    data_signed_value = (MSB << 8) | LSB
    if data_signed_value == 0x8000:
        data_signed_value = 0.0
    elif (data_signed_value & 0x8000) == 0x8000:
        data_signed_value = -((0xFFFF - data_signed_value)+1)
    return data_signed_value


def Odom_Trans(MSB, LSB):
    data_signed_value = (MSB << 8) | LSB
    if data_signed_value == 0x8000:
        data_signed_value = 0.0
    elif (data_signed_value & 0x8000) == 0x8000:
        data_signed_value = -((0xFFFF - data_signed_value)+1)
    data_signed_value = (data_signed_value / 1000.00)#+((data_signed_value % 1000.00)*0.001)
    return data_signed_value

# variable for controlling api
FRAME_HEADER = 0x7B
FRAME_TAIL = 0x7D
AutoRecharge = 0x00
ROS_control = 0x00
Recharge_control = 0x01
RedDocker_control = 0x03
Maximum_linear_speed = 1.50   # 0.12799 m/s
Miniimum_linear_speed = -1.50 #-0.12799 # m/s
Percent_speed = 100

# variable for IMU and Odom
IMU_Odom_FrameHeader = 0x7B
IMU_Odom_FrameTail = 0x7D
IMU_Odom_dataLenght = 23
Accel_ratio = 1671.84
Gyroscope_ratio = 0.00026644

# variable for Ultrasonics
Ultrasonic_FrameHeader = 0xFA
Ultrasonic_FrameTail = 0xFC
Ultrasonic_dataLenght = 18

# variable for Auto charge
AutoCharge_FrameHeader = 0x7C
AutoCharge_FrameTail = 0x7F
AutoCharge_dataLenght = 7

node = ""
Navigation_reach_target = 0
time_stamp_navigation_first_tick = 0

# variable for Protection Sensor
MarkerArray_publisher = ''
protection_sensor_data = [0, 0, 0, 0, 0]
buffer_sensor_data = [0, 0, 0, 0, 0]
sensor_detceted = 0
timer = 0.00
color_a = 0.00
blink_state = 0.00

def map_speed(value):
    in_min = 1
    in_max = 100
    out_min = 0.25
    out_max = 0.6
    in_range = in_max - in_min
    out_range = out_max - out_min
    if value == 0: 
        return 0
    else:
        mapped_value = (value - in_min) * (out_range / in_range) + out_min
        return mapped_value

def callback_cmd_vel(msg):
    global AutoRecharge, Percent_speed
    ########## Speed limit ##########
    current_speed_limit = map_speed(Percent_speed)
    vel_x = msg.linear.x # in m/s unit
    if vel_x > current_speed_limit:
        vel_x = current_speed_limit
    elif vel_x < -current_speed_limit:
        vel_x = -current_speed_limit
    vel_x_byte_H = (int(vel_x*1000)&0xFF00)>>8
    vel_x_byte_L = (int(vel_x*1000)&0x00FF)
    #print("vel_x_byte_H:" + str(vel_x_byte_H))
    #print("vel_x_byte_L:" + str(vel_x_byte_L))

    vel_y = msg.linear.y # in m/s unit
    if vel_y > current_speed_limit:
        vel_y = current_speed_limit
    elif vel_y < -current_speed_limit:
        vel_y = -current_speed_limit
    vel_y_byte_H = (int(vel_y*1000)&0xFF00)>>8
    vel_y_byte_L = (int(vel_y*1000)&0x00FF)

    vel_z = msg.angular.z # in rad/s unit
    if current_speed_limit == 0:
        vel_z = 0
    vel_z_byte_H = (int(vel_z*1000)&0xFF00)>>8
    vel_z_byte_L = (int(vel_z*1000)&0x00FF)
    ################################

    cmd_vel = []
    cmd_vel.append(FRAME_HEADER)
    cmd_vel.append(AutoRecharge) # ROS Conrtol = 0x00 , Recharge mode = 0x01
    cmd_vel.append(0x00) # set aside

    cmd_vel.append(vel_x_byte_H)
    cmd_vel.append(vel_x_byte_L)
    cmd_vel.append(vel_y_byte_H)
    cmd_vel.append(vel_y_byte_L)
    cmd_vel.append(vel_z_byte_H)
    cmd_vel.append(vel_z_byte_L)

    cmd_vel.append(checksum(cmd_vel,9))
    cmd_vel.append(FRAME_TAIL)

    comport.write(cmd_vel)

def Red_Vel_Callback(msg):
    ########## Speed limit ##########
    vel_x = msg.linear.x # in m/s unit
    if vel_x > Maximum_linear_speed:
        vel_x = Maximum_linear_speed
    elif vel_x < Miniimum_linear_speed:
        vel_x = Miniimum_linear_speed
    vel_x_byte_H = (int(vel_x*1000)&0xFF00)>>8
    vel_x_byte_L = (int(vel_x*1000)&0x00FF)

    vel_y = msg.linear.y # in m/s unit
    if vel_y > Maximum_linear_speed:
        vel_y = Maximum_linear_speed
    elif vel_y < Miniimum_linear_speed:
        vel_y = Miniimum_linear_speed
    vel_y_byte_H = (int(vel_y*1000)&0xFF00)>>8
    vel_y_byte_L = (int(vel_y*1000)&0x00FF)

    vel_z = msg.angular.z # in rad/s unit
    if vel_z > Maximum_linear_speed:
        vel_z = Maximum_linear_speed
    elif vel_z < Miniimum_linear_speed:
        vel_z = Miniimum_linear_speed
    vel_z_byte_H = (int(vel_z*1000)&0xFF00)>>8
    vel_z_byte_L = (int(vel_z*1000)&0x00FF)
    ################################

    cmd_vel = []
    cmd_vel.append(FRAME_HEADER)
    cmd_vel.append(RedDocker_control)
    cmd_vel.append(0x00) # set aside

    cmd_vel.append(vel_x_byte_H)
    cmd_vel.append(vel_x_byte_L)
    cmd_vel.append(vel_y_byte_H)
    cmd_vel.append(vel_y_byte_L)
    cmd_vel.append(vel_z_byte_H)
    cmd_vel.append(vel_z_byte_L)

    cmd_vel.append(checksum(cmd_vel,9))
    cmd_vel.append(FRAME_TAIL)

    comport.write(cmd_vel)

def Recharge_Flag_Callback(Recharge_Flag):
    global AutoRecharge
    AutoRecharge=Recharge_Flag.data
    
def Robot_Status_Callback(Navigation_Status):
    global node, Navigation_reach_target, time_stamp_navigation_first_tick
    #print("Robot status from Driver.")
    #node.get_logger().info("Robot status from Driver.")
    data_len = len(Navigation_Status.status_list)
    status_num = Navigation_Status.status_list[data_len - 1].status
    if status_num == 4: # reach the goal.
        print("Navigation send: Reach the goal.")
        node.get_logger().info("Navigation send: Reach the goal.")
        Navigation_reach_target = 1
    elif status_num == 2:
        print("Beary-x navigate to pose action status: going to the target.")
        node.get_logger().info("Beary-x navigate to pose action status: going to the target.")
        Navigation_reach_target = 0
    elif status_num == 5:
        print("Beary-x navigate to pose action status: canceling.")
        node.get_logger().info("Beary-x navigate to pose action status: canceling.")
        Navigation_reach_target = 3
    elif status_num == 6:
        print("Beary-x navigate to pose action status: aborting.")
        node.get_logger().info("Beary-x navigate to pose action status: aborting.")
        Navigation_reach_target = 2


def Bearyx_clear_alarm_Callback(protection_flag):
    global sensor_detceted
    if protection_flag.data == True:
        clearMarker()
        sensor_detceted = 0
        

def Set_Speed_Callback(Speed):
    global Percent_speed
    Percent_speed = Speed.data
    if Percent_speed < 0:
        Percent_speed = 0
    elif Percent_speed > 100:
        Percent_speed = 100
    
        
def turnOn_Robot():
    cmd_vel = []
    cmd_vel.append(FRAME_HEADER)
    cmd_vel.append(ROS_control)
    cmd_vel.append(0x00) # set aside
    cmd_vel.append(0x00)
    cmd_vel.append(0x00)
    cmd_vel.append(0x00)
    cmd_vel.append(0x00)
    cmd_vel.append(0x00)
    cmd_vel.append(0x00)
    cmd_vel.append(checksum(cmd_vel,9))
    cmd_vel.append(FRAME_TAIL)
    comport.write(cmd_vel)
    print("Beary-X is turn on.")

def publishMarker(type, sensor, text):
    global MarkerArray_publisher, timer, color_a, blink_state

    if (time.time() - timer < 2.00):
        if (time.time() - timer < 1.00):
            color_a = time.time() - timer
            blink_state = 1.00
        else:
            color_a = 0.10 / ((time.time() - timer) - 0.90)
            blink_state = 0.20
    else:
        timer = time.time()

    markerArray = MarkerArray()
    alarm_marker_shape = Marker() 
    marker_string = Marker() 
    
    alarm_marker_shape.id = 0 
    alarm_marker_shape.header.frame_id = "base_link" 
    alarm_marker_shape.type = alarm_marker_shape.MESH_RESOURCE 
    alarm_marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/alarm.STL"
    alarm_marker_shape.action = alarm_marker_shape.ADD 
    alarm_marker_shape.scale.x = 0.001 
    alarm_marker_shape.scale.y = 0.001 
    alarm_marker_shape.scale.z = 0.001 
    alarm_marker_shape.color.a = blink_state
    alarm_marker_shape.color.r = 1.00
    alarm_marker_shape.color.g = 0.00 
    alarm_marker_shape.color.b = 0.00 
    alarm_marker_shape.pose.position.z = 0.65 
    markerArray.markers.append(alarm_marker_shape) 

    marker_shape = Marker() 
    marker_shape.id = 1 
    marker_shape.header.frame_id = "base_link" 
    marker_shape.type = marker_shape.MESH_RESOURCE 

    if type == "bumper_sensor":
        marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/bumper.STL"
        marker_shape.action = marker_shape.ADD 
        marker_shape.scale.x = 0.00101 
        marker_shape.scale.y = 0.00101 
        marker_shape.scale.z = 0.001 
        marker_shape.color.a = color_a
        marker_shape.color.r = 1.00
        marker_shape.color.g = 0.00 
        marker_shape.color.b = 0.00 
        marker_shape.pose.position.z = 0.01 
        markerArray.markers.append(marker_shape) 
    elif type == "fall_sensor":
        if sensor == 1:
            marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/fall_sensor_1.STL"
        elif sensor == 2:
            marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/fall_sensor_2.STL"
        elif sensor == 3:
            marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/fall_sensor_3.STL"
        elif sensor == 4:
            marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/fall_sensor_4.STL"
        marker_shape.action = marker_shape.ADD 
        marker_shape.scale.x = 0.00101 
        marker_shape.scale.y = 0.00101 
        marker_shape.scale.z = 0.001 
        marker_shape.color.a = 1.00
        marker_shape.color.r = 1.00
        marker_shape.color.g = 0.00 
        marker_shape.color.b = 0.00 
        marker_shape.pose.position.z = color_a / 10.00 
        markerArray.markers.append(marker_shape) 

    marker_string.id = 2 
    marker_string.header.frame_id = "base_link"
    marker_string.type = marker_string.TEXT_VIEW_FACING 
    marker_string.action = marker_string.ADD 
    marker_string.scale.x = 0.2 
    marker_string.scale.y = 0.2 
    marker_string.scale.z = 0.2 
    marker_string.color.a = 1.00 
    marker_string.color.r = 1.00 
    marker_string.color.g = 0.00 
    marker_string.color.b = 0.00 
    marker_string.pose.position.z = 0.90 
    marker_string.text = text
    markerArray.markers.append(marker_string) 

    MarkerArray_publisher.publish(markerArray)

def clearMarker():
    global MarkerArray_publisher
    print("Clear alarm.")
    node.get_logger().info("Clear alarm.")
    markerArray = MarkerArray()
    marker = Marker()
    marker.id = 0
    marker.header.frame_id = "base_link"
    marker.action = marker.DELETEALL
    markerArray.markers.append(marker) 

    marker = Marker()
    marker.id = 1
    marker.header.frame_id = "base_link"
    marker.action = marker.DELETEALL
    markerArray.markers.append(marker) 

    marker = Marker()
    marker.id = 2
    marker.header.frame_id = "base_link"
    marker.action = marker.DELETEALL
    markerArray.markers.append(marker) 

    MarkerArray_publisher.publish(markerArray) 

Odom_Robot_Vel = {
    'x':0.00,
    'y':0.00,
    'z':0.00
}

IMU_MPU6050_data = {
    'accele_x':0.00,
    'accele_y':0.00,
    'accele_z':0.00,
    'gyro_x':0.00,
    'gyro_y':0.00,
    'gyro_z':0.00,
    'linear_acceleration_x':0.00,
    'linear_acceleration_y':0.00,
    'linear_acceleration_z':0.00,
    'angular_velocity_x':0.00,
    'angular_velocity_y':0.00,
    'angular_velocity_z':0.00
}

Ultrasonic_sensor = {
        'sensor1':0,
        'sensor2':0,
        'sensor3':0,
        'sensor4':0,
        'sensor5':0,
        'sensor6':0,
    }


def BearyX_sensor_thread_function(sensor):
    global comport, comport_sensor, MarkerArray_publisher, sensor_detceted, protection_sensor_data
    sensor_detceted = 0
    clearMarker()
    while True:
        try:
            buffer_sensor_data = comport_sensor.readline().decode('utf-8') # bumper_value,fall_value_1,fall_value_2,fall_value_3,fall_value_4\n
            buffer_sensor_data = buffer_sensor_data.split(",")
            if (buffer_sensor_data[0] == '1' or buffer_sensor_data[1] == '1' or buffer_sensor_data[2] == '1' or buffer_sensor_data[3] == '1' or buffer_sensor_data[4] == '1') and sensor_detceted == 0:
                sensor_detceted = 1
                cmd_vel = []
                cmd_vel.append(FRAME_HEADER)
                cmd_vel.append(ROS_control)
                cmd_vel.append(0x00) # set aside
                cmd_vel.append(0x00)
                cmd_vel.append(0x00)
                cmd_vel.append(0x00)
                cmd_vel.append(0x00)
                cmd_vel.append(0x00)
                cmd_vel.append(0x00)
                cmd_vel.append(checksum(cmd_vel,9))
                cmd_vel.append(FRAME_TAIL)
                comport.write(cmd_vel)
                protection_sensor_data = buffer_sensor_data.copy()
                print("Please run command 'ros2 run bearyx_bringup clear_alarm' for clearing the alarm.")
                node.get_logger().info("Please run command 'ros2 run bearyx_bringup clear_alarm' for clearing the alarm.")

                # for checking the service between cartogapher and navigation
                result = subprocess.run(['ros2', 'service','list'], stdout=subprocess.PIPE)
                num_check = str(result).find("waypoint_follower")
                #print("num_check: " + str(num_check))
                #node.get_logger().info("num_check: " + str(num_check))
                if num_check > 0:
                    os.system("ros2 service call '/navigate_to_pose/_action/cancel_goal' 'action_msgs/srv/CancelGoal'")
                
            if sensor_detceted == 1:
                if protection_sensor_data[0] == '1':
                    publishMarker("bumper_sensor", 1, "BumperHit")
                elif protection_sensor_data[1] == '1':
                    publishMarker("fall_sensor", 1, "Falling1")
                elif protection_sensor_data[2] == '1':
                    publishMarker("fall_sensor", 2, "Falling2")
                elif protection_sensor_data[3] == '1':
                    publishMarker("fall_sensor", 3, "Falling3")
                elif protection_sensor_data[4] == '1':
                    publishMarker("fall_sensor", 4, "Falling4")
        except:
            print("Error from Beary-X sensor.")
        
        time.sleep(0.05)

def main(args=None):
    global node, Navigation_reach_target, time_stamp_navigation_first_tick, MarkerArray_publisher, Percent_speed, wheels_vel
    turnOn_Robot()
    rclpy.init(args=args)

    node = rclpy.create_node('BearyX_driver')

    # Publisher object
    imu_publisherObject = node.create_publisher(Imu, '/imu' , 10)
    odom_publisherObject = node.create_publisher( Odometry, '/odom' , 10)
    battery_publisherObject = node.create_publisher(BatteryState , '/battery_state' , 10)

    distance1_publisherObject = node.create_publisher(Range , '/ultrasonic_1' , 2)
    distance2_publisherObject = node.create_publisher(Range , '/ultrasonic_2' , 2)
    distance3_publisherObject = node.create_publisher(Range , '/ultrasonic_3' , 2)
    distance4_publisherObject = node.create_publisher(Range , '/ultrasonic_4' , 2)
    distance5_publisherObject = node.create_publisher(Range , '/ultrasonic_5' , 2)
    distance6_publisherObject = node.create_publisher(Range , '/ultrasonic_6' , 2)

    charging_publisherObject = node.create_publisher(Bool , '/robot_charging_flag' , 10) # robot charging flag
    charging_current_publisherObject = node.create_publisher(Float32 , '/robot_charging_current' , 10) # charging current
    redDocker_publisherObject = node.create_publisher(Bool , '/robot_red_flag' , 10) # Create a topic publisher that finds the infrared signal flag bit

    MarkerArray_publisher = node.create_publisher(MarkerArray, '/alarm_maker', 10)
    current_speed_publisher = node.create_publisher(Int8, '/get_speed', 10)

    network_publisherObject = node.create_publisher(String , '/robot_info' , 1)

    #Start Subscribe
    subscription = node.create_subscription(Twist, '/cmd_vel', callback_cmd_vel,20)
    subscription = node.create_subscription(Twist, '/red_vel', Red_Vel_Callback,10)
    subscription = node.create_subscription(Int8, '/robot_recharge_flag', Recharge_Flag_Callback,10)
    subscription = node.create_subscription(GoalStatusArray, '/navigate_to_pose/_action/status', Robot_Status_Callback,10)
    subscription = node.create_subscription(Bool, '/bearyx_protection_sensor', Bearyx_clear_alarm_Callback,10)
    subscription = node.create_subscription(Int8, '/set_speed', Set_Speed_Callback,10)

    # Topic data
    imu = Imu()
    imu.header.frame_id = "imu_link" #"base_imu_link"
    
    odom = Odometry()
    odom.header.frame_id = "odom"
    odom.child_frame_id = "base_footprint"

    initial_pose = PoseWithCovarianceStamped()
    initial_pose.header.frame_id = "map"

    vel_linear_x = 0
    vel_linear_y = 0
    diff_vel_yaw = 0

    BearyX_voltage = 0

    odom_pose_x = 0
    odom_pose_y = 0
    odom_yaw = 0
    z = 0
    w = 0
    last_time_odom = 0.0
    diff_x_pose = 0
    diff_y_pose = 0
    diff_yaw_pose = 0

    now_odom = time.time()
    vel_dt = now_odom - last_time_odom # sec unit
    last_time_odom = now_odom

    print("Beary-X is ready for operation.")
    node.get_logger().info("Beary-X is ready for operation.")
    
    read_imu_thread = threading.Thread(target=IMUThread, args=(1,))
    read_imu_thread.start()

    while rclpy.ok:
        try:
            rclpy.spin_once(node, executor=None,timeout_sec = 0.005) #0.005

            start_byte = int.from_bytes(comport.read(),"big")
            #print(start_byte)
            if start_byte == IMU_Odom_FrameHeader:
                data_buffer_IMU_Odom = comport.read(IMU_Odom_dataLenght)
                if data_buffer_IMU_Odom[22] == IMU_Odom_FrameTail:
                    try:
                        Odom_Robot_Vel['x'] = Odom_Trans(data_buffer_IMU_Odom[1],data_buffer_IMU_Odom[2]) # unit meters/s 
                        Odom_Robot_Vel['y'] = Odom_Trans(data_buffer_IMU_Odom[3],data_buffer_IMU_Odom[4]) # unit meters/s 
                        Odom_Robot_Vel['z'] = Odom_Trans(data_buffer_IMU_Odom[5],data_buffer_IMU_Odom[6]) # unit rad/s

                        vel_linear_x = Odom_Robot_Vel['x']
                        vel_linear_y = Odom_Robot_Vel['y']
                        diff_vel_yaw = Odom_Robot_Vel['z']
                        
                        if abs(vel_linear_x) > 0 or abs(vel_linear_y) > 0 or abs(diff_vel_yaw) > 0:
                            wheels_vel = 1
                        else:
                            wheels_vel = 0

                        #print("vel_linear_x: " + str(vel_linear_x))

                        ################ Filter noise #####################
                        # if (vel_linear_x > 0.997) and (vel_linear_x < 0.999):
                        #     vel_linear_x = 0.00
                        # elif (vel_linear_x > 0.001) and (vel_linear_x < 0.003):
                        #     vel_linear_x = 0.00

                        Power_voltage_byte = (data_buffer_IMU_Odom[19]<<8) + data_buffer_IMU_Odom[20]
                        BearyX_voltage_raw = (Power_voltage_byte/1000)+((Power_voltage_byte % 1000)*0.001)
                        # percent = int(28.571*float(BearyX_voltage) - 585.714)
                        BearyX_voltage = (0.5830 * BearyX_voltage_raw) + 8.9382 - 0.2  #(0.637*BearyX_voltage_raw)+7.52 + 0.5
                        percent = (50*BearyX_voltage) - 1040
                        if percent >= 100:
                            percent = 100
                        elif percent <= 0:
                            percent = 0

                        if math.isnan(Battery_Current):
                            Battery_Current = 0

                        print("========================================")
                        print(BearyX_voltage_raw)
                        print(BearyX_voltage)
                        print(Battery_Current)
                        print("========================================")

                        data_Battery = BatteryState()
                        data_Battery.header.frame_id = "battery_frame"
                        data_Battery.header.stamp = node.get_clock().now().to_msg()
                        data_Battery.voltage = BearyX_voltage
                        data_Battery.percentage = percent
                        data_Battery.current = Battery_Current
                        data_Battery.charge = 40.0
                        data_Battery.capacity = 100.0
                        data_Battery.design_capacity = 100.0
                        data_Battery.power_supply_status = 2
                        data_Battery.power_supply_health = 1
                        data_Battery.power_supply_technology = 2
                        data_Battery.present = True
                        #data_Battery.data  = json.dumps({"BearyX voltage raw":BearyX_voltage_raw, "Battery voltage": BearyX_voltage, "Battery Percent": percent})
                        battery_publisherObject.publish(data_Battery)
                        #print(data_Battery)

                        """
                        #print("========================================")
                        #print("odom_x: " + str(Odom_Robot_Vel['x']))
                        #print("odom_y: " + str(Odom_Robot_Vel['y']))
                        #print("odom_z: " + str(Odom_Robot_Vel['z']))
                        print("========================================")
                        print("accele_x: " + str(accel_x))
                        print("accele_y: " + str(accel_y))
                        print("accele_z: " + str(accel_z))
                        print("========================================")
                        print("gyros_x: " + str(gyro_x))
                        print("gyros_y: " + str(gyro_y))
                        print("gyros_z: " + str(gyro_z))
                        print("========================================")
                        print("BearyX_voltage: " + str(BearyX_voltage))
                        """
                    
                    except :
                        #clean up on exit
                        print("Error from reading serial IMU_Odom.")

                    try:
                        ###################### odom_raw(Pose) Part #####################
                        now_odom = time.time()
                        vel_dt = now_odom - last_time_odom # sec unit
                        
                        diff_x_pose = ((vel_linear_x * math.cos(odom_yaw)) - (vel_linear_y * math.sin(odom_yaw))) * vel_dt
                        diff_y_pose = ((vel_linear_x * math.sin(odom_yaw)) + (vel_linear_y * math.cos(odom_yaw))) * vel_dt
                        diff_yaw_pose = diff_vel_yaw * vel_dt # rad unit
                        
                        if diff_x_pose >= abs(0.001):
                            odom_pose_x = odom_pose_x + diff_x_pose # meter unit
                        else:
                            odom_pose_x = odom_pose_x + 0.00
                        
                        if diff_y_pose >= abs(0.001):
                            odom_pose_y = odom_pose_y + diff_y_pose # meter unit
                        else:
                            odom_pose_y = odom_pose_y + 0.00

                        if diff_yaw_pose >= abs(0.05):
                            odom_yaw = odom_yaw + diff_yaw_pose # rad unit
                        else:
                            odom_yaw = odom_yaw + 0.00 # rad unit
                        
                        odom_pose_x = odom_pose_x + diff_x_pose # meter unit
                        odom_pose_y = odom_pose_y + diff_y_pose # meter unit
                        odom_yaw = odom_yaw + diff_yaw_pose # rad unit
                        last_time_odom = now_odom
                        
                        z = math.sin(odom_yaw/2)
                        w = math.cos(odom_yaw/2)
                        
                        odom.header.stamp = node.get_clock().now().to_msg()
                        odom.pose.pose.position.x = odom_pose_x
                        odom.pose.pose.position.y = odom_pose_y
                        odom.pose.pose.position.z = 0.0
                        odom.pose.pose.orientation.x = 0.0
                        odom.pose.pose.orientation.y = 0.0
                        odom.pose.pose.orientation.z = z
                        odom.pose.pose.orientation.w = w
                        odom.pose.covariance = [1e-9, 0.0, 0.0, 0.0, 0.0, 0.0, 
                                                0.0, 1e-3, 1e-9, 0.0, 0.0, 0.0, 
                                                0.0, 0.0, 1e6, 0.0, 0.0, 0.0,
                                                0.0, 0.0, 0.0, 1e6, 0.0, 0.0, 
                                                0.0, 0.0, 0.0, 0.0, 1e6, 0.0, 
                                                0.0, 0.0, 0.0, 0.0, 0.0, 1e3 ]

                        odom.twist.twist.linear.x = vel_linear_x
                        odom.twist.twist.linear.y = vel_linear_y
                        odom.twist.twist.linear.z = 0.0
                        odom.twist.twist.angular.x = 0.0
                        odom.twist.twist.angular.y = 0.0
                        odom.twist.twist.angular.z = diff_vel_yaw
                        odom.twist.covariance = [1e-9, 0.0, 0.0, 0.0, 0.0, 0.0, 
                                                0.0, 1e-3, 1e-9, 0.0, 0.0, 0.0, 
                                                0.0, 0.0, 1e6, 0.0, 0.0, 0.0,
                                                0.0, 0.0, 0.0, 1e6, 0.0, 0.0, 
                                                0.0, 0.0, 0.0, 0.0, 1e6, 0.0, 
                                                0.0, 0.0, 0.0, 0.0, 0.0, 0.1]
                        odom_publisherObject.publish(odom)

                        print("=======================================")
                        print("odom_pose_x:" + str(odom_pose_x))
                        print("odom_pose_y:" + str(odom_pose_y))
                        print("odom_yaw:" + str(odom_yaw))
                        print("vel_linear_x:" + str(vel_linear_x))
                        print("vel_linear_y:" + str(vel_linear_y))
                        print("diff_vel_yaw:" + str(diff_vel_yaw))
                        print("=======================================")
                        
                        ###################### IMU Part #####################
                        
                        imu.header.stamp = node.get_clock().now().to_msg()
                        imu.linear_acceleration.x = 0.0
                        imu.linear_acceleration.y = 0.0
                        imu.linear_acceleration.z = 0.0
                        imu.linear_acceleration_covariance = [ 1e6, 0.0, 0.0,
                                                                0.0, 1e6, 0.0,
                                                                0.0, 0.0, 1e-6 ]
                        imu.angular_velocity.x = 0.0
                        imu.angular_velocity.y = 0.0
                        imu.angular_velocity.z = float(angular_velocity[2])
                        imu.angular_velocity_covariance = [ 1e6, 0.0, 0.0,
                                                            0.0, 1e6, 0.0,
                                                            0.0, 0.0, 1e-6 ]
                        imu_orientation = tf_transformations.quaternion_from_euler(math.radians(0), math.radians(0), math.radians(last_valid_imu[2]))
                        imu.orientation.x = imu_orientation[0]
                        imu.orientation.y = imu_orientation[1]
                        imu.orientation.z = imu_orientation[2]
                        imu.orientation.w = imu_orientation[3]
                        imu.orientation_covariance = [  1e6, 0.0, 0.0,
                                                        0.0, 1e6, 0.0,
                                                        0.0, 0.0, 1e-6 ]
                        imu_publisherObject.publish(imu)
                        #time.sleep(0.001)

                        # Navigation goal force stop
                        if Navigation_reach_target == 1 or Navigation_reach_target == 2 or Navigation_reach_target == 3:
                            if (time.time() - time_stamp_navigation_first_tick) >= 1:
                                cmd_vel = []
                                cmd_vel.append(FRAME_HEADER)
                                cmd_vel.append(ROS_control)
                                cmd_vel.append(0x00) # set aside
                                cmd_vel.append(0x00)
                                cmd_vel.append(0x00)
                                cmd_vel.append(0x00)
                                cmd_vel.append(0x00)
                                cmd_vel.append(0x00)
                                cmd_vel.append(0x00)
                                cmd_vel.append(checksum(cmd_vel,9))
                                cmd_vel.append(FRAME_TAIL)
                                comport.write(cmd_vel)

                                if time.time() - time_stamp_navigation_first_tick >= 3:
                                    Navigation_reach_target = 0
                                elif Navigation_reach_target == 1:
                                    print("Force Stop from reach the goal.")
                                    node.get_logger().info("Force Stop from reach the goal.")
                                elif Navigation_reach_target == 2:
                                    print("Force Stop from aborting.")
                                    node.get_logger().info("Force Stop from aborting.")
                                elif Navigation_reach_target == 3:
                                    print("Force Stop from canceling.")
                                    node.get_logger().info("Force Stop from canceling.")

                                

                    except:
                        #clean up on exit
                        print("Error publish odom and imu.")

            elif start_byte == Ultrasonic_FrameHeader:
                data_buffer_Ultrasonics = comport.read(Ultrasonic_dataLenght)
                if data_buffer_Ultrasonics[17] == Ultrasonic_FrameTail:
                    try:
                        Ultrasonic_sensor['sensor1'] = ((data_buffer_Ultrasonics[0]<<8) + data_buffer_Ultrasonics[1])/1000.0
                        Ultrasonic_sensor['sensor2'] = ((data_buffer_Ultrasonics[2]<<8) + data_buffer_Ultrasonics[3])/1000.0
                        Ultrasonic_sensor['sensor3'] = ((data_buffer_Ultrasonics[4]<<8) + data_buffer_Ultrasonics[5])/1000.0
                        Ultrasonic_sensor['sensor4'] = ((data_buffer_Ultrasonics[6]<<8) + data_buffer_Ultrasonics[7])/1000.0
                        Ultrasonic_sensor['sensor5'] = ((data_buffer_Ultrasonics[8]<<8) + data_buffer_Ultrasonics[9])/1000.0
                        Ultrasonic_sensor['sensor6'] = ((data_buffer_Ultrasonics[10]<<8) + data_buffer_Ultrasonics[11])/1000.0
                        
                        #print(Ultrasonic_sensor['sensor2'])

                        #distance = str(Ultrasonic_sensor['sensor1']) + "," + str(Ultrasonic_sensor['sensor2']) + "," + str(Ultrasonic_sensor['sensor3']) + "," + str(Ultrasonic_sensor['sensor4']) + "," + str(Ultrasonic_sensor['sensor5']) + "," + str(Ultrasonic_sensor['sensor6'])
                        #Distance_Ultrasonics = String()
                        #Distance_Ultrasonics.data = str(distance)
                        #distance_publisherObject.publish(Distance_Ultrasonics)

                        min_range = 0.02
                        max_range = 0.1

                        sonar = Range()
                        sonar.header.stamp = node.get_clock().now().to_msg()
                        sonar.header.frame_id = "ultrasonic_link_1"
                        sonar.radiation_type = 0
                        sonar.field_of_view = 0.1308
                        sonar.min_range = min_range
                        sonar.max_range = max_range
                        sonar.range = Ultrasonic_sensor['sensor1']
                        distance1_publisherObject.publish(sonar)

                        sonar = Range()
                        sonar.header.stamp = node.get_clock().now().to_msg()
                        sonar.header.frame_id = "ultrasonic_link_2"
                        sonar.radiation_type = 0
                        sonar.field_of_view = 0.1308
                        sonar.min_range = min_range
                        sonar.max_range = max_range
                        sonar.range = Ultrasonic_sensor['sensor2']
                        distance2_publisherObject.publish(sonar)

                        sonar = Range()
                        sonar.header.stamp = node.get_clock().now().to_msg()
                        sonar.header.frame_id = "ultrasonic_link_3"
                        sonar.radiation_type = 0
                        sonar.field_of_view = 0.1308
                        sonar.min_range = min_range
                        sonar.max_range = max_range
                        sonar.range = Ultrasonic_sensor['sensor3']
                        distance3_publisherObject.publish(sonar)

                        sonar = Range()
                        sonar.header.stamp = node.get_clock().now().to_msg()
                        sonar.header.frame_id = "ultrasonic_link_4"
                        sonar.radiation_type = 0
                        sonar.field_of_view = 0.1308
                        sonar.min_range = 0.02
                        sonar.max_range = 0.05
                        sonar.range = Ultrasonic_sensor['sensor4']
                        distance4_publisherObject.publish(sonar)

                        sonar = Range()
                        sonar.header.stamp = node.get_clock().now().to_msg()
                        sonar.header.frame_id = "ultrasonic_link_5"
                        sonar.radiation_type = 0
                        sonar.field_of_view = 0.1308
                        sonar.min_range = min_range
                        sonar.max_range = max_range
                        sonar.range = Ultrasonic_sensor['sensor5']
                        distance5_publisherObject.publish(sonar)

                        sonar = Range()
                        sonar.header.stamp = node.get_clock().now().to_msg()
                        sonar.header.frame_id = "ultrasonic_link_6"
                        sonar.radiation_type = 0
                        sonar.field_of_view = 0.1308
                        sonar.min_range = min_range
                        sonar.max_range = max_range
                        sonar.range = Ultrasonic_sensor['sensor6']
                        distance6_publisherObject.publish(sonar)


                        data_network = String()
                        data_network.data  = json.dumps(BearyX_info)
                        network_publisherObject.publish(data_network)
                        
                    except:
                        #clean up on exit
                        print("Error publish ultrasonics.")

            elif start_byte == AutoCharge_FrameHeader:
                data_buffer_AutoCharge = comport.read(AutoCharge_dataLenght)
                if data_buffer_AutoCharge[6] == AutoCharge_FrameTail:
                    try:
                        Charging_Current_byte =  (data_buffer_AutoCharge[0]<<8) + data_buffer_AutoCharge[1]
                        Charging_Current = (Charging_Current_byte/1000) + ((Charging_Current_byte%1000)*0.001)
                        red = data_buffer_AutoCharge[2]
                        Charging = data_buffer_AutoCharge[3]
                        
                        #print(Charging_Current)
                        #print(Charging)

                        if Charging == False:
                            Charging_Current = 0.00

                        if Charging_Current > 4.00:
                            Charging_Current = 4.00
                        elif Charging_Current < 0:
                            Charging_Current = 0
                        
                        Battery_Current = Charging_Current
                        
                        Charging_flag = Bool()
                        Charging_flag.data = bool(Charging)
                        charging_publisherObject.publish(Charging_flag)

                        Charging_Current_str = Float32()
                        Charging_Current_str.data = Charging_Current
                        charging_current_publisherObject.publish(Charging_Current_str)

                        RedDocker = Bool()
                        RedDocker.data = bool(red)
                        redDocker_publisherObject.publish(RedDocker)
                    
                    except:
                        #clean up on exit
                        print("Error publish Auto charge frame.")
                        
            speed_data = Int8()
            speed_data.data = Percent_speed
            current_speed_publisher.publish(speed_data)

        except KeyboardInterrupt:
            comport.close()
            print("KeyboardInterrupt")
            print("Close program.")
            
            
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
