import rclpy
from rclpy.node import Node
import math

import time
import serial

from std_msgs.msg import String, Int8, Bool,Float32
from nav_msgs.msg import Odometry
from actionlib_msgs.msg import GoalID
from geometry_msgs.msg import PoseWithCovarianceStamped

# for maker
from visualization_msgs.msg import Marker
from visualization_msgs.msg import MarkerArray

MarkerArray_publisher = ''
p_x = 0.0
p_y = 0.0
o_z = 0.0
o_w = 0.0

sensor_detceted = 0
timer = 0.00
color_a = 0.00
blink_state = 0.00

comport = serial.Serial("/dev/ttyUSB3", 115200, timeout = 5)
comport.close()
comport.open()

def publishMarker(data):
    global MarkerArray_publisher, p_x, p_y, o_z, o_w, timer, color_a, blink_state

    if (time.time() - timer < 2.00):
        if (time.time() - timer < 1.00):
            color_a = time.time() - timer
            blink_state = 1.00
        else:
            color_a = 0.10 / ((time.time() - timer) - 0.90)
            blink_state = 0.20
    else:
        timer = time.time()

    markerArray = MarkerArray()
    alarm_marker_shape = Marker() 
    marker_string = Marker() 
    
    alarm_marker_shape.id = 0 
    alarm_marker_shape.header.frame_id = "base_link" 
    alarm_marker_shape.type = alarm_marker_shape.MESH_RESOURCE 
    alarm_marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/alarm.STL"
    alarm_marker_shape.action = alarm_marker_shape.ADD 
    alarm_marker_shape.scale.x = 0.001 
    alarm_marker_shape.scale.y = 0.001 
    alarm_marker_shape.scale.z = 0.001 
    alarm_marker_shape.color.a = blink_state
    alarm_marker_shape.color.r = 1.00
    alarm_marker_shape.color.g = 0.00 
    alarm_marker_shape.color.b = 0.00 
    alarm_marker_shape.pose.position.z = 0.65 
    markerArray.markers.append(alarm_marker_shape) 

    marker_shape = Marker() 
    marker_shape.id = 1 
    marker_shape.header.frame_id = "base_link" 
    marker_shape.type = marker_shape.MESH_RESOURCE 

    if (data == "bumper_hit"):
        marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/bumper.STL"
        marker_shape.action = marker_shape.ADD 
        marker_shape.scale.x = 0.00101 
        marker_shape.scale.y = 0.00101 
        marker_shape.scale.z = 0.001 
        marker_shape.color.a = color_a
        marker_shape.color.r = 1.00
        marker_shape.color.g = 0.00 
        marker_shape.color.b = 0.00 
        marker_shape.pose.position.z = 0.01 
        markerArray.markers.append(marker_shape) 
        marker_string.text = "BumperHit"
    elif (data == "fall_1"):
        marker_shape.mesh_resource = "package://bearyx_bringup/meshes/stl/fall_sensor_1.STL"
        marker_shape.action = marker_shape.ADD 
        marker_shape.scale.x = 0.00101 
        marker_shape.scale.y = 0.00101 
        marker_shape.scale.z = 0.001 
        marker_shape.color.a = 1.00
        marker_shape.color.r = 1.00
        marker_shape.color.g = 0.00 
        marker_shape.color.b = 0.00 
        marker_shape.pose.position.z = color_a / 10.00 
        markerArray.markers.append(marker_shape) 
        marker_string.text = "Fall"

    marker_string.id = 2 
    marker_string.header.frame_id = "base_link"
    marker_string.type = marker_string.TEXT_VIEW_FACING 
    marker_string.action = marker_string.ADD 
    marker_string.scale.x = 0.2 
    marker_string.scale.y = 0.2 
    marker_string.scale.z = 0.2 
    marker_string.color.a = 1.00 
    marker_string.color.r = 1.00 
    marker_string.color.g = 0.00 
    marker_string.color.b = 0.00 
    marker_string.pose.position.z = 0.90 
    markerArray.markers.append(marker_string) 

    MarkerArray_publisher.publish(markerArray)

def deleteMarker():
    markerArray = MarkerArray()
    marker = Marker()
    marker.id = 0
    marker.header.frame_id = "map"
    marker.action = marker.DELETEALL
    markerArray.markers.append(marker) 

    marker = Marker()
    marker.id = 1
    marker.header.frame_id = "map"
    marker.action = marker.DELETEALL
    markerArray.markers.append(marker) 

    MarkerArray_publisher.publish(markerArray) 
    
def Pose_tracking_listener_callback(data):
    global p_x, p_y, o_z, o_w
    p_x = float(data.pose.pose.position.x)
    p_y = float(data.pose.pose.position.y)
    o_z = float(data.pose.pose.orientation.z)
    o_w = float(data.pose.pose.orientation.w)
    # print(data.pose.pose.position.x)

def main(args=None):
    global MarkerArray_publisher, sensor_detceted

    rclpy.init(args=args)

    node = rclpy.create_node('BearyX_protection_service')
    bumper_publisherObject = node.create_publisher(Bool , 'bumper' , 10)
    fall_sensor1_publisherObject = node.create_publisher(Bool , 'fall_sensor_1' , 10)
    fall_sensor2_publisherObject = node.create_publisher(Bool , 'fall_sensor_2' , 10)
    fall_sensor3_publisherObject = node.create_publisher(Bool , 'fall_sensor_3' , 10)
    fall_sensor4_publisherObject = node.create_publisher(Bool , 'fall_sensor_4' , 10)
    MarkerArray_publisher = node.create_publisher(MarkerArray, 'path_point', 10)
    CancelNav_publisher = node.create_publisher(GoalID, "goal_cancel", 10)

    #Start Subscribe
    subscription = node.create_subscription(PoseWithCovarianceStamped, '/amcl_pose', Pose_tracking_listener_callback, 10)

    while rclpy.ok:
        try:
            rclpy.spin_once(node, executor=None,timeout_sec =0.005) #0.005
            protection_sensor_data = comport.readline().decode('utf-8')
            protection_sensor_data = protection_sensor_data.split(",")

            if (protection_sensor_data[0] == '1'):
                sensor_detceted = 1

            if (sensor_detceted == 1):
                publishMarker("bumper_hit")

            Bumper = Bool()
            Bumper.data = not not(int(protection_sensor_data[0]))
            bumper_publisherObject.publish(Bumper)

            FallSensor1 = Bool()
            FallSensor1.data = not not(int(protection_sensor_data[1]))
            fall_sensor1_publisherObject.publish(FallSensor1)

            FallSensor2 = Bool()
            FallSensor2.data = not not(int(protection_sensor_data[2]))
            fall_sensor2_publisherObject.publish(FallSensor2)

            FallSensor3 = Bool()
            FallSensor3.data = not not(int(protection_sensor_data[3]))
            fall_sensor3_publisherObject.publish(FallSensor3)

            FallSensor4 = Bool()
            FallSensor4.data = not not(int(protection_sensor_data[4]))
            fall_sensor4_publisherObject.publish(FallSensor4)

        except KeyboardInterrupt:
            comport.close()
            print("KeyboardInterrupt")
            print("Close program.")

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()