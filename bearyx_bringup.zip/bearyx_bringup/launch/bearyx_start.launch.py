import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.actions import IncludeLaunchDescription
from launch.actions import ExecuteProcess
from launch.substitutions import FindExecutable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_xml.launch_description_sources import XMLLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch.conditions import IfCondition

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    use_cam = LaunchConfiguration('use_cam', default=False)

    robot_localization_file_path = os.path.join(get_package_share_directory('bearyx_bringup'), 'config', 'ekf.yaml') 
    robot_state_publisher_file_dir = os.path.join(get_package_share_directory('bearyx_gazebo'))
    orbbec_3D_camera_launch_file_dir = os.path.join(get_package_share_directory('orbbec_camera'))
    rosbridge_launch_file_dir = os.path.join(get_package_share_directory('rosbridge_server'), 'launch')

    ros2_laser_scan_merger_launch_file_dir = os.path.join(get_package_share_directory('ros2_laser_scan_merger'), 'launch')
    pointcloud_to_laserscan_launch_file_dir = os.path.join(get_package_share_directory('pointcloud_to_laserscan'), 'launch')

    lsm10p_front_lidar_dir = os.path.join(get_package_share_directory('lslidar_driver'), 'launch')
    lsm10p_back_lidar_dir = os.path.join(get_package_share_directory('lslidar_driver'), 'launch')

    return LaunchDescription([

        DeclareLaunchArgument(
             name='use_cam',
             default_value='False',
             description='Add use_cam:=true to activate the depth camera.'),

        Node(
            package='bearyx_bringup',
            executable='bearyx_driver',
            name='bearyx_driver',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],
            remappings=[
                ('/imu', '/imu/data'),
                ('/odom', '/wheel/odometry'),]
        ),
        
        Node(
            package='imu_complementary_filter', # sudo apt install ros-foxy-imu-complementary-filter
            executable='complementary_filter_node',
            name='imu_filter_node_for_orientation',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],
        ),

        Node(
            package='robot_localization', # sudo apt install ros-foxy-robot-localization
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[robot_localization_file_path, 
            {'use_sim_time': use_sim_time}],
            remappings=[("/odometry/filtered", "/odom")],
        ),

         IncludeLaunchDescription(
             XMLLaunchDescriptionSource([orbbec_3D_camera_launch_file_dir, '/launch/astra_stereo_u3.launch.xml']),
             launch_arguments={'use_sim_time': use_sim_time,}.items(), condition=IfCondition(use_cam)
         ),

         # --- Image Transport Node for Compression ---
        Node(
            package='image_transport',
            executable='republish',
            name='image_compression_node',
            output='screen',
            arguments=['raw', 'compressed'],
            remappings=[
                ('in', '/camera/color/image_raw'),
                ('out/compressed', '/camera/color/image_raw/compressed')
            ]
        ),
         
         ExecuteProcess(
		cmd=[[
		    FindExecutable(name='ros2'),
		    " service call ",
		    "/camera/set_depth_mirror ",
		    "std_srvs/srv/SetBool ",
		    '"{data: false}"',
		]],
		shell=True
    	),
    	
    	ExecuteProcess(
		cmd=[[
		    FindExecutable(name='ros2'),
		    " service call ",
		    "/camera/set_color_gain ",
		    "orbbec_camera_msgs/srv/SetInt32 ",
		    '"{data: 10}"',
		]],
		shell=True
    	),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([lsm10p_front_lidar_dir, '/lsm10p_front_launch.py']),
            launch_arguments={'use_sim_time': use_sim_time}.items(),
        ), 

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([lsm10p_back_lidar_dir, '/lsm10p_back_launch.py']),
            launch_arguments={'use_sim_time': use_sim_time}.items(),
        ), 

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([ros2_laser_scan_merger_launch_file_dir, '/merge_2_scan.launch.py']),
            launch_arguments={ 'use_sim_time': use_sim_time,}.items(),
            
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([pointcloud_to_laserscan_launch_file_dir, '/sample_pointcloud_to_laserscan_launch.py']),
            launch_arguments={ 'use_sim_time': use_sim_time,}.items(),
        ),

        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([robot_state_publisher_file_dir, '/bearyx_robot_state_publisher.launch.py']),
            launch_arguments={'use_sim_time': use_sim_time}.items(),
        ),

        IncludeLaunchDescription(
            XMLLaunchDescriptionSource([rosbridge_launch_file_dir, '/rosbridge_websocket_launch.xml']),
            launch_arguments={'use_sim_time': use_sim_time}.items(),
        ),

        # Add Node-RED Execution Process
        ExecuteProcess(
            cmd=['node-red'],
            name='node_red',
            output='screen',
            shell=True,
        ),
    ])
