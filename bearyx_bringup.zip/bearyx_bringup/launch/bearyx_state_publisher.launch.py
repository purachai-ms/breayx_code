#!/usr/bin/env python3

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    use_sim_time = LaunchConfiguration('use_sim_time', default='False')
    urdf_file_name = 'bearyx.urdf'

    urdf = os.path.join(
        get_package_share_directory('bearyx_bringup'),
        'urdf',
        urdf_file_name)

    rviz_config_dir = os.path.join(
        get_package_share_directory('bearyx_bringup'),
        'rviz',
        'urdf.rviz')
    
    return LaunchDescription([
        
        DeclareLaunchArgument(
            'use_sim_time',
            default_value='False',
            description='Use simulation (Gazebo) clock if true'),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],
            arguments=[urdf]),

        Node(
            package='bearyx_bringup',
            executable='bearyx_imu',
            name='bearyx_imu',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],
            remappings=[
                ('/imu', '/imu/data_raw')]),

        Node(
            package='imu_complementary_filter',
            executable='complementary_filter_node',
            name='imu_filter_node_for_orientation',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],),

        Node(
            package='bearyx_bringup',
            executable='tf_broadcaster_imu',
            name='bearyx_imu',
            output='screen',
            parameters=[{'use_sim_time': use_sim_time}],),

        Node(
            package='rviz2',
            executable='rviz2',
            name='rviz2',
            arguments=['-d', rviz_config_dir],
            parameters=[{'use_sim_time': use_sim_time}],
            output='screen'), 
    ])
